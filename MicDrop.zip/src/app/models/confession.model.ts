export interface Confession {
}
